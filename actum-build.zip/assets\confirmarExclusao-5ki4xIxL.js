function o(n,r,t){const i=prompt(`Pra confirmar, digite ${n} exato:

"${r}"`);if(i!==null){if(i.trim()!==String(r).trim()){alert("Não confere — nada foi excluído.");return}t()}}export{o as c};
