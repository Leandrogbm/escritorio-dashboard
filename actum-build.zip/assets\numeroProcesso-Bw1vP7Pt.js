import{c as i,x as c,y as s,z as p}from"./index-gELTHKsR.js";/**
 * @license lucide-react v0.383.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=i("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]]);/**
 * @license lucide-react v0.383.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=i("Download",[["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}],["polyline",{points:"7 10 12 15 17 10",key:"2ggqvy"}],["line",{x1:"12",x2:"12",y1:"15",y2:"3",key:"1vk2je"}]]);/**
 * @license lucide-react v0.383.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const f=i("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]);function h(a,e,r,o){const l=c(a==null?void 0:a.plano),t=l==null?void 0:l[e];if(t==null||r<t)return null;const n=s(l.value);return n?`Limite de ${t} ${o} do plano ${l.label} atingido. Faça upgrade para o plano ${p(n)} pra continuar cadastrando (fale com o suporte da plataforma).`:`Limite de ${t} ${o} do plano ${l.label} atingido. Fale com o suporte da plataforma.`}function m(a){const e=(a||"").replace(/\D/g,"").slice(0,20);return e?e.length<=7?e:e.length<=9?`${e.slice(0,7)}-${e.slice(7)}`:e.length<=13?`${e.slice(0,7)}-${e.slice(7,9)}.${e.slice(9)}`:e.length<=14?`${e.slice(0,7)}-${e.slice(7,9)}.${e.slice(9,13)}.${e.slice(13)}`:e.length<=16?`${e.slice(0,7)}-${e.slice(7,9)}.${e.slice(9,13)}.${e.slice(13,14)}.${e.slice(14)}`:`${e.slice(0,7)}-${e.slice(7,9)}.${e.slice(9,13)}.${e.slice(13,14)}.${e.slice(14,16)}.${e.slice(16)}`:""}export{d as A,u as D,f as F,h as a,m as f};
